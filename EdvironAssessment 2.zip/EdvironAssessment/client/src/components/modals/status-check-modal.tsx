import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { transactionsApi } from "../../lib/api";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { Transaction } from "@shared/schema";

interface StatusCheckModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function StatusCheckModal({ isOpen, onClose }: StatusCheckModalProps) {
  const [customOrderId, setCustomOrderId] = useState("");
  const [result, setResult] = useState<Transaction | null>(null);
  const [error, setError] = useState<string | null>(null);

  const statusMutation = useMutation({
    mutationFn: (orderId: string) => transactionsApi.getTransactionStatus(orderId),
    onSuccess: (data) => {
      setResult(data);
      setError(null);
    },
    onError: (error: any) => {
      setError(error.message || "Transaction not found");
      setResult(null);
    },
  });

  const handleCheckStatus = () => {
    if (!customOrderId.trim()) {
      setError("Please enter a custom order ID");
      return;
    }
    
    statusMutation.mutate(customOrderId.trim());
  };

  const handleClose = () => {
    setCustomOrderId("");
    setResult(null);
    setError(null);
    onClose();
  };

  const getStatusBadge = (status: string) => {
    const baseClasses = "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium";
    
    switch (status) {
      case "success":
        return `${baseClasses} bg-success/10 text-success`;
      case "pending":
        return `${baseClasses} bg-warning/10 text-warning`;
      case "failed":
        return `${baseClasses} bg-destructive/10 text-destructive`;
      default:
        return `${baseClasses} bg-muted text-muted-foreground`;
    }
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString("en-US", { 
      year: "numeric", 
      month: "short", 
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Check Transaction Status</DialogTitle>
          <p className="text-sm text-muted-foreground">Enter custom order ID to check status</p>
        </DialogHeader>
        
        <div className="space-y-6">
          <div>
            <Label htmlFor="customOrderId" className="block text-sm font-medium text-foreground mb-2">
              Custom Order ID
            </Label>
            <Input
              id="customOrderId"
              type="text"
              placeholder="e.g., ORD-2024-001247"
              className="w-full"
              value={customOrderId}
              onChange={(e) => setCustomOrderId(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleCheckStatus();
                }
              }}
              data-testid="input-custom-order-id"
            />
          </div>
          
          <Button
            className="w-full"
            onClick={handleCheckStatus}
            disabled={statusMutation.isPending}
            data-testid="button-check-status"
          >
            {statusMutation.isPending ? (
              <>
                <i className="fas fa-spinner fa-spin mr-2"></i>Checking...
              </>
            ) : (
              <>
                <i className="fas fa-search mr-2"></i>Check Status
              </>
            )}
          </Button>
          
          {/* Error State */}
          {error && (
            <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg">
              <div className="flex items-center text-destructive">
                <i className="fas fa-exclamation-circle mr-2"></i>
                <span className="text-sm font-medium" data-testid="text-error">
                  {error}
                </span>
              </div>
            </div>
          )}
          
          {/* Success Result */}
          {result && (
            <div className="bg-muted rounded-lg p-4" data-testid="status-result">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-muted-foreground">Transaction Status</span>
                <span className={getStatusBadge(result.status)} data-testid="status-badge">
                  {result.status.charAt(0).toUpperCase() + result.status.slice(1)}
                </span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Order ID:</span>
                  <span className="font-medium" data-testid="text-order-id">
                    {result.custom_order_id}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Collect ID:</span>
                  <span className="font-medium" data-testid="text-collect-id">
                    {result.collect_id}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Student:</span>
                  <span className="font-medium" data-testid="text-student-name">
                    {result.student_info.name}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Amount:</span>
                  <span className="font-medium" data-testid="text-amount">
                    ₹{result.transaction_amount.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Gateway:</span>
                  <span className="font-medium" data-testid="text-gateway">
                    {result.gateway}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Payment Time:</span>
                  <span className="font-medium" data-testid="text-payment-time">
                    {formatDate(result.payment_time)}
                  </span>
                </div>
                {result.payment_message && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Message:</span>
                    <span className="font-medium" data-testid="text-payment-message">
                      {result.payment_message}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

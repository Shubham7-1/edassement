import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { transactionsApi } from "../../lib/api";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import type { Transaction } from "@shared/schema";

interface SchoolTransactionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SchoolTransactionsModal({ isOpen, onClose }: SchoolTransactionsModalProps) {
  const [selectedSchoolId, setSelectedSchoolId] = useState<string>("");

  const { data, isLoading } = useQuery({
    queryKey: ["/api/transactions/school", selectedSchoolId],
    queryFn: () => selectedSchoolId ? transactionsApi.getTransactionsBySchool(selectedSchoolId) : Promise.resolve(null),
    enabled: !!selectedSchoolId,
  });

  const schools = [
    { id: "65b0e6293e9f76a9694d84b4", name: "Delhi Public School" },
    { id: "65b0e6293e9f76a9694d84b5", name: "Ryan International" },
    { id: "65b0e6293e9f76a9694d84b6", name: "Kendriya Vidyalaya" },
  ];

  const getStatusBadge = (status: string) => {
    const baseClasses = "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium";
    
    switch (status) {
      case "success":
        return `${baseClasses} bg-success/10 text-success`;
      case "pending":
        return `${baseClasses} bg-warning/10 text-warning`;
      case "failed":
        return `${baseClasses} bg-destructive/10 text-destructive`;
      default:
        return `${baseClasses} bg-muted text-muted-foreground`;
    }
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString("en-US", { 
      year: "numeric", 
      month: "short", 
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle>School Transactions</DialogTitle>
          <p className="text-sm text-muted-foreground">View transactions for specific schools</p>
        </DialogHeader>
        
        <div className="space-y-6">
          <div>
            <Label className="block text-sm font-medium text-foreground mb-2">Select School</Label>
            <Select
              value={selectedSchoolId}
              onValueChange={setSelectedSchoolId}
            >
              <SelectTrigger className="w-full" data-testid="select-school-modal">
                <SelectValue placeholder="Choose a school..." />
              </SelectTrigger>
              <SelectContent>
                {schools.map((school) => (
                  <SelectItem key={school.id} value={school.id}>
                    {school.name} (ID: {school.id})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="max-h-96 overflow-y-auto">
            {!selectedSchoolId && (
              <div className="text-center py-8 text-muted-foreground">
                <i className="fas fa-school text-4xl mb-4"></i>
                <p>Select a school to view its transactions</p>
              </div>
            )}

            {selectedSchoolId && isLoading && (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="p-4 border border-border rounded-lg">
                    <Skeleton className="h-4 w-32 mb-2" />
                    <Skeleton className="h-4 w-48 mb-2" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                ))}
              </div>
            )}

            {selectedSchoolId && !isLoading && data?.transactions && data.transactions.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <i className="fas fa-inbox text-4xl mb-4"></i>
                <p>No transactions found for this school</p>
              </div>
            )}

            {selectedSchoolId && !isLoading && data?.transactions && data.transactions.length > 0 && (
              <div className="space-y-4">
                {data.transactions.map((transaction: Transaction) => (
                  <div 
                    key={transaction.collect_id} 
                    className="p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors"
                    data-testid={`card-transaction-${transaction.collect_id}`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <p className="font-medium text-foreground" data-testid={`text-order-id-${transaction.collect_id}`}>
                          {transaction.custom_order_id}
                        </p>
                        <p className="text-sm text-muted-foreground" data-testid={`text-collect-id-${transaction.collect_id}`}>
                          Collect ID: {transaction.collect_id}
                        </p>
                      </div>
                      <span className={getStatusBadge(transaction.status)} data-testid={`status-${transaction.collect_id}`}>
                        {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Student:</p>
                        <p className="font-medium" data-testid={`text-student-name-${transaction.collect_id}`}>
                          {transaction.student_info.name}
                        </p>
                        <p className="text-xs text-muted-foreground" data-testid={`text-student-email-${transaction.collect_id}`}>
                          {transaction.student_info.email}
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Amount:</p>
                        <p className="font-semibold text-foreground" data-testid={`text-amount-${transaction.collect_id}`}>
                          ₹{transaction.transaction_amount.toLocaleString()}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Gateway: {transaction.gateway}
                        </p>
                      </div>
                    </div>
                    
                    <div className="mt-3 pt-3 border-t border-border text-xs text-muted-foreground">
                      <div className="flex justify-between">
                        <span>Payment Mode: {transaction.payment_mode}</span>
                        <span data-testid={`text-payment-date-${transaction.collect_id}`}>
                          {formatDate(transaction.payment_time)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

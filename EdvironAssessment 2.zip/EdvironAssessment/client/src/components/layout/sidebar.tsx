import { Link, useLocation } from "wouter";
import { useTheme } from "../theme-provider";

export function Sidebar() {
  const [location] = useLocation();
  const { theme, toggleTheme } = useTheme();

  const navItems = [
    { href: "/", label: "Transactions Overview", icon: "fas fa-chart-line" },
    { href: "/school-transactions", label: "School Transactions", icon: "fas fa-school" },
    { href: "/status-check", label: "Status Check", icon: "fas fa-search" },
  ];

  return (
    <aside className="w-64 bg-card border-r border-border flex flex-col">
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <i className="fas fa-graduation-cap text-primary-foreground text-xl"></i>
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">Edviron</h1>
            <p className="text-sm text-muted-foreground">Payment Dashboard</p>
          </div>
        </div>
      </div>
      
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div 
                className={`flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors cursor-pointer ${
                  isActive 
                    ? "bg-primary text-primary-foreground" 
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                }`}
                data-testid={`nav-${item.href.slice(1) || 'dashboard'}`}
              >
                <i className={item.icon}></i>
                <span>{item.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-border">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Dark Mode</span>
          <button 
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
              theme === "dark" ? "bg-primary" : "bg-gray-200"
            }`}
            onClick={toggleTheme}
            data-testid="button-dark-mode-toggle"
          >
            <span 
              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                theme === "dark" ? "translate-x-6" : "translate-x-1"
              }`}
            ></span>
          </button>
        </div>
      </div>
    </aside>
  );
}

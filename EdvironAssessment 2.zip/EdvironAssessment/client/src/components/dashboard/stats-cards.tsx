import { useQuery } from "@tanstack/react-query";
import { dashboardApi } from "../../lib/api";
import { Skeleton } from "@/components/ui/skeleton";

export function StatsCards() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    queryFn: dashboardApi.getStats,
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="bg-card rounded-xl border border-border p-6 shadow-sm">
            <Skeleton className="h-4 w-32 mb-2" />
            <Skeleton className="h-8 w-20 mb-2" />
            <Skeleton className="h-3 w-24" />
          </div>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: "Total Transactions",
      value: stats?.totalTransactions.toLocaleString() || "0",
      trend: "+12% from last month",
      icon: "fas fa-exchange-alt",
      bgColor: "bg-chart-1/10",
      iconColor: "text-chart-1",
    },
    {
      title: "Successful Payments",
      value: stats?.successfulPayments.toLocaleString() || "0",
      trend: `${stats?.successRate || "0"}% success rate`,
      icon: "fas fa-check-circle",
      bgColor: "bg-success/10",
      iconColor: "text-success",
    },
    {
      title: "Total Revenue",
      value: `₹${stats?.totalRevenue.toLocaleString() || "0"}`,
      trend: "+8.2% from last month",
      icon: "fas fa-rupee-sign",
      bgColor: "bg-chart-3/10",
      iconColor: "text-chart-3",
    },
    {
      title: "Failed Transactions",
      value: stats?.failedTransactions.toLocaleString() || "0",
      trend: `${stats?.failureRate || "0"}% failure rate`,
      icon: "fas fa-times-circle",
      bgColor: "bg-destructive/10",
      iconColor: "text-destructive",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {cards.map((card, index) => (
        <div key={index} className="bg-card rounded-xl border border-border p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground" data-testid={`text-${card.title.toLowerCase().replace(/\s+/g, '-')}`}>
                {card.title}
              </p>
              <p className="text-2xl font-bold text-foreground" data-testid={`text-${card.title.toLowerCase().replace(/\s+/g, '-')}-value`}>
                {card.value}
              </p>
              <p className="text-xs text-success mt-1">
                <i className="fas fa-arrow-up mr-1"></i>
                {card.trend}
              </p>
            </div>
            <div className={`w-12 h-12 ${card.bgColor} rounded-lg flex items-center justify-center`}>
              <i className={`${card.icon} ${card.iconColor} text-xl`}></i>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

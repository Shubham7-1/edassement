import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { TransactionFilters } from "../../types";

interface FiltersSectionProps {
  onFiltersChange: (filters: TransactionFilters) => void;
  filters: TransactionFilters;
}

export function FiltersSection({ onFiltersChange, filters }: FiltersSectionProps) {
  const [localFilters, setLocalFilters] = useState<TransactionFilters>(filters);

  const handleInputChange = (key: keyof TransactionFilters, value: string) => {
    const newFilters = { ...localFilters, [key]: (value && value !== "all") ? value : undefined };
    setLocalFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const clearFilters = () => {
    const clearedFilters = { 
      page: 1, 
      limit: 10, 
      status: "all", 
      schoolId: "all", 
      search: "",
      fromDate: "",
      toDate: ""
    };
    setLocalFilters(clearedFilters);
    onFiltersChange(clearedFilters);
  };

  return (
    <div className="bg-card rounded-xl border border-border p-6 mb-6 shadow-sm">
      <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-end">
        {/* Search */}
        <div className="flex-1 min-w-0">
          <Label htmlFor="search" className="block text-sm font-medium text-foreground mb-2">
            Search Transactions
          </Label>
          <div className="relative">
            <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"></i>
            <Input
              id="search"
              type="text"
              placeholder="Search by collect ID, school ID, or student name..."
              className="w-full pl-10 pr-4 py-3 bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
              value={localFilters.search || ""}
              onChange={(e) => handleInputChange("search", e.target.value)}
              data-testid="input-search"
            />
          </div>
        </div>

        {/* Status Filter */}
        <div className="w-full lg:w-48">
          <Label className="block text-sm font-medium text-foreground mb-2">Status</Label>
          <Select
            value={localFilters.status || "all"}
            onValueChange={(value) => handleInputChange("status", value)}
          >
            <SelectTrigger className="w-full" data-testid="select-status">
              <SelectValue placeholder="All Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="success">Success</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* School Filter */}
        <div className="w-full lg:w-48">
          <Label className="block text-sm font-medium text-foreground mb-2">School</Label>
          <Select
            value={localFilters.schoolId || "all"}
            onValueChange={(value) => handleInputChange("schoolId", value)}
          >
            <SelectTrigger className="w-full" data-testid="select-school">
              <SelectValue placeholder="All Schools" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Schools</SelectItem>
              <SelectItem value="65b0e6293e9f76a9694d84b4">Delhi Public School</SelectItem>
              <SelectItem value="65b0e6293e9f76a9694d84b5">Ryan International</SelectItem>
              <SelectItem value="65b0e6293e9f76a9694d84b6">Kendriya Vidyalaya</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Date Range */}
        <div className="flex gap-2 w-full lg:w-auto">
          <div>
            <Label htmlFor="fromDate" className="block text-sm font-medium text-foreground mb-2">
              From Date
            </Label>
            <Input
              id="fromDate"
              type="date"
              className="px-4 py-3 bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
              value={localFilters.fromDate || ""}
              onChange={(e) => handleInputChange("fromDate", e.target.value)}
              data-testid="input-from-date"
            />
          </div>
          <div>
            <Label htmlFor="toDate" className="block text-sm font-medium text-foreground mb-2">
              To Date
            </Label>
            <Input
              id="toDate"
              type="date"
              className="px-4 py-3 bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
              value={localFilters.toDate || ""}
              onChange={(e) => handleInputChange("toDate", e.target.value)}
              data-testid="input-to-date"
            />
          </div>
        </div>

        {/* Clear Filters Button */}
        <Button
          variant="secondary"
          onClick={clearFilters}
          className="px-6 py-3 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80 transition-colors font-medium whitespace-nowrap"
          data-testid="button-clear-filters"
        >
          <i className="fas fa-times mr-2"></i>Clear Filters
        </Button>
      </div>
    </div>
  );
}

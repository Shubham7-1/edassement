import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { transactionsApi } from "../../lib/api";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import type { TransactionFilters } from "../../types";
import type { Transaction } from "@shared/schema";

interface TransactionsTableProps {
  filters: TransactionFilters;
}

export function TransactionsTable({ filters }: TransactionsTableProps) {
  const [sortField, setSortField] = useState<string>("");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["/api/transactions", filters],
    queryFn: () => transactionsApi.getAllTransactions(filters),
  });

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("desc");
    }
  };

  const handlePageChange = (newPage: number) => {
    // This would typically be handled by the parent component
    console.log("Page change requested:", newPage);
  };

  const getStatusBadge = (status: string) => {
    const baseClasses = "status-badge inline-flex items-center px-2 py-1 rounded-full text-xs font-medium";
    
    switch (status) {
      case "success":
        return `${baseClasses} bg-success/10 text-success`;
      case "pending":
        return `${baseClasses} bg-warning/10 text-warning`;
      case "failed":
        return `${baseClasses} bg-destructive/10 text-destructive`;
      default:
        return `${baseClasses} bg-muted text-muted-foreground`;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "success":
        return "fas fa-check-circle";
      case "pending":
        return "fas fa-clock";
      case "failed":
        return "fas fa-times-circle";
      default:
        return "fas fa-question-circle";
    }
  };

  const formatDate = (date: Date | string) => {
    const d = new Date(date);
    return d.toLocaleDateString("en-US", { 
      year: "numeric", 
      month: "short", 
      day: "numeric" 
    });
  };

  const formatTime = (date: Date | string) => {
    const d = new Date(date);
    return d.toLocaleTimeString("en-US", { 
      hour: "2-digit", 
      minute: "2-digit" 
    });
  };

  if (isLoading) {
    return (
      <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
        <div className="p-6">
          <Skeleton className="h-6 w-48 mb-2" />
          <Skeleton className="h-4 w-32" />
        </div>
        <div className="p-6 space-y-4">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Transaction History</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Showing {((filters.page || 1) - 1) * (filters.limit || 10) + 1}-{Math.min(((filters.page || 1) * (filters.limit || 10)), data?.total || 0)} of {data?.total || 0} transactions
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="default"
              size="sm"
              onClick={() => {
                // TODO: Implement export functionality
                console.log("Export data");
              }}
              data-testid="button-export"
            >
              <i className="fas fa-download mr-2"></i>Export
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => refetch()}
              data-testid="button-refresh"
            >
              <i className="fas fa-refresh mr-2"></i>Refresh
            </Button>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/50">
            <tr>
              <th className="px-6 py-4 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                <button 
                  className="flex items-center space-x-1 hover:text-foreground"
                  onClick={() => handleSort("collect_id")}
                  data-testid="button-sort-collect-id"
                >
                  <span>Collect ID</span>
                  <i className="fas fa-sort text-xs"></i>
                </button>
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                <button 
                  className="flex items-center space-x-1 hover:text-foreground"
                  onClick={() => handleSort("school_id")}
                  data-testid="button-sort-school"
                >
                  <span>School</span>
                  <i className="fas fa-sort text-xs"></i>
                </button>
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Student Details
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                <button 
                  className="flex items-center space-x-1 hover:text-foreground"
                  onClick={() => handleSort("transaction_amount")}
                  data-testid="button-sort-amount"
                >
                  <span>Amount</span>
                  <i className="fas fa-sort text-xs"></i>
                </button>
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Gateway
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                <button 
                  className="flex items-center space-x-1 hover:text-foreground"
                  onClick={() => handleSort("status")}
                  data-testid="button-sort-status"
                >
                  <span>Status</span>
                  <i className="fas fa-sort text-xs"></i>
                </button>
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                <button 
                  className="flex items-center space-x-1 hover:text-foreground"
                  onClick={() => handleSort("payment_time")}
                  data-testid="button-sort-date"
                >
                  <span>Payment Time</span>
                  <i className="fas fa-sort text-xs"></i>
                </button>
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {data?.transactions?.map((transaction: Transaction) => (
              <tr 
                key={transaction.collect_id} 
                className="table-hover cursor-pointer hover:bg-muted/50 hover:shadow-sm transition-all duration-200"
                data-testid={`row-transaction-${transaction.collect_id}`}
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-foreground" data-testid={`text-collect-id-${transaction.collect_id}`}>
                    #{transaction.collect_id.slice(-6)}
                  </div>
                  <div className="text-xs text-muted-foreground" data-testid={`text-custom-order-id-${transaction.collect_id}`}>
                    {transaction.custom_order_id}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-foreground" data-testid={`text-school-name-${transaction.collect_id}`}>
                    {transaction.school_name || "School Name"}
                  </div>
                  <div className="text-xs text-muted-foreground" data-testid={`text-school-id-${transaction.collect_id}`}>
                    {transaction.school_id}
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm font-medium text-foreground" data-testid={`text-student-name-${transaction.collect_id}`}>
                    {transaction.student_info.name}
                  </div>
                  <div className="text-xs text-muted-foreground" data-testid={`text-student-id-${transaction.collect_id}`}>
                    {transaction.student_info.id}
                  </div>
                  <div className="text-xs text-muted-foreground" data-testid={`text-student-email-${transaction.collect_id}`}>
                    {transaction.student_info.email}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-semibold text-foreground" data-testid={`text-transaction-amount-${transaction.collect_id}`}>
                    ₹{transaction.transaction_amount.toLocaleString()}
                  </div>
                  <div className="text-xs text-muted-foreground" data-testid={`text-order-amount-${transaction.collect_id}`}>
                    Order: ₹{transaction.order_amount.toLocaleString()}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <i className="fas fa-mobile-alt text-primary mr-2"></i>
                    <span className="text-sm font-medium" data-testid={`text-gateway-${transaction.collect_id}`}>
                      {transaction.gateway}
                    </span>
                  </div>
                  <div className="text-xs text-muted-foreground" data-testid={`text-payment-mode-${transaction.collect_id}`}>
                    {transaction.payment_mode}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={getStatusBadge(transaction.status)} data-testid={`status-${transaction.collect_id}`}>
                    <i className={`${getStatusIcon(transaction.status)} mr-1`}></i>
                    {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-foreground" data-testid={`text-payment-date-${transaction.collect_id}`}>
                    {formatDate(transaction.payment_time)}
                  </div>
                  <div className="text-xs text-muted-foreground" data-testid={`text-payment-time-${transaction.collect_id}`}>
                    {formatTime(transaction.payment_time)}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center space-x-2">
                    <button 
                      className="p-1 rounded hover:bg-accent text-muted-foreground hover:text-accent-foreground"
                      title="View Details"
                      data-testid={`button-view-details-${transaction.collect_id}`}
                    >
                      <i className="fas fa-eye"></i>
                    </button>
                    <button 
                      className="p-1 rounded hover:bg-accent text-muted-foreground hover:text-accent-foreground"
                      title="Download Receipt"
                      data-testid={`button-download-receipt-${transaction.collect_id}`}
                    >
                      <i className="fas fa-receipt"></i>
                    </button>
                  </div>
                </td>
              </tr>
            )) || []}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="px-6 py-4 border-t border-border">
        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            Showing {((filters.page || 1) - 1) * (filters.limit || 10) + 1} to {Math.min(((filters.page || 1) * (filters.limit || 10)), data?.total || 0)} of {data?.total || 0} results
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handlePageChange((filters.page || 1) - 1)}
              disabled={(filters.page || 1) <= 1}
              data-testid="button-previous-page"
            >
              <i className="fas fa-chevron-left mr-1"></i>Previous
            </Button>
            
            <div className="flex space-x-1">
              <Button
                variant={(filters.page || 1) === 1 ? "default" : "outline"}
                size="sm"
                data-testid="button-page-1"
              >
                1
              </Button>
              {(data?.totalPages || 0) > 1 && (
                <Button
                  variant={(filters.page || 1) === 2 ? "default" : "outline"}
                  size="sm"
                  onClick={() => handlePageChange(2)}
                  data-testid="button-page-2"
                >
                  2
                </Button>
              )}
              {(data?.totalPages || 0) > 2 && (
                <>
                  <span className="px-3 py-2 text-muted-foreground">...</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handlePageChange(data?.totalPages || 1)}
                    data-testid={`button-page-${data?.totalPages}`}
                  >
                    {data?.totalPages}
                  </Button>
                </>
              )}
            </div>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => handlePageChange((filters.page || 1) + 1)}
              disabled={(filters.page || 1) >= (data?.totalPages || 1)}
              data-testid="button-next-page"
            >
              Next<i className="fas fa-chevron-right ml-1"></i>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

export interface DashboardStats {
  totalTransactions: number;
  successfulPayments: number;
  failedTransactions: number;
  totalRevenue: number;
  successRate: string;
  failureRate: string;
}

export interface TransactionFilters {
  search?: string;
  status?: string;
  schoolId?: string;
  fromDate?: string;
  toDate?: string;
  page?: number;
  limit?: number;
}

export interface PaginatedResponse<T> {
  transactions?: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface User {
  id: string;
  username: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

import { useState } from "react";
import { Header } from "../components/layout/header";
import { StatsCards } from "../components/dashboard/stats-cards";
import { FiltersSection } from "../components/dashboard/filters-section";
import { TransactionsTable } from "../components/dashboard/transactions-table";
import { SchoolTransactionsModal } from "../components/modals/school-transactions-modal";
import { StatusCheckModal } from "../components/modals/status-check-modal";
import type { TransactionFilters } from "../types";

export default function Dashboard() {
  const [filters, setFilters] = useState<TransactionFilters>({
    page: 1,
    limit: 10,
  });
  const [isSchoolModalOpen, setIsSchoolModalOpen] = useState(false);
  const [isStatusModalOpen, setIsStatusModalOpen] = useState(false);

  const handleFiltersChange = (newFilters: TransactionFilters) => {
    setFilters({ ...newFilters, page: 1 }); // Reset to first page when filters change
  };

  return (
    <>
      <Header 
        title="Transactions Overview" 
        subtitle="Manage and monitor payment transactions" 
      />
      
      <div className="flex-1 overflow-auto p-6">
        <StatsCards />
        <FiltersSection 
          filters={filters}
          onFiltersChange={handleFiltersChange}
        />
        <TransactionsTable filters={filters} />
      </div>

      <SchoolTransactionsModal
        isOpen={isSchoolModalOpen}
        onClose={() => setIsSchoolModalOpen(false)}
      />

      <StatusCheckModal
        isOpen={isStatusModalOpen}
        onClose={() => setIsStatusModalOpen(false)}
      />
    </>
  );
}

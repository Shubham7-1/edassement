import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { transactionsApi } from "../lib/api";
import { Header } from "../components/layout/header";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import type { Transaction } from "@shared/schema";

export default function SchoolTransactions() {
  const [selectedSchoolId, setSelectedSchoolId] = useState<string>("");

  const { data, isLoading } = useQuery({
    queryKey: ["/api/transactions/school", selectedSchoolId],
    queryFn: () => selectedSchoolId ? transactionsApi.getTransactionsBySchool(selectedSchoolId) : Promise.resolve(null),
    enabled: !!selectedSchoolId,
  });

  const schools = [
    { id: "65b0e6293e9f76a9694d84b4", name: "Delhi Public School" },
    { id: "65b0e6293e9f76a9694d84b5", name: "Ryan International" },
    { id: "65b0e6293e9f76a9694d84b6", name: "Kendriya Vidyalaya" },
  ];

  const getStatusBadge = (status: string) => {
    const baseClasses = "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium";
    
    switch (status) {
      case "success":
        return `${baseClasses} bg-success/10 text-success`;
      case "pending":
        return `${baseClasses} bg-warning/10 text-warning`;
      case "failed":
        return `${baseClasses} bg-destructive/10 text-destructive`;
      default:
        return `${baseClasses} bg-muted text-muted-foreground`;
    }
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString("en-US", { 
      year: "numeric", 
      month: "short", 
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  return (
    <>
      <Header 
        title="School Transactions" 
        subtitle="View and manage transactions by school" 
      />
      
      <div className="flex-1 overflow-auto p-6">
        <div className="max-w-4xl mx-auto">
          <div className="bg-card rounded-xl border border-border p-6 mb-6 shadow-sm">
            <Label className="block text-sm font-medium text-foreground mb-2">Select School</Label>
            <Select
              value={selectedSchoolId}
              onValueChange={setSelectedSchoolId}
            >
              <SelectTrigger className="w-full max-w-md" data-testid="select-school">
                <SelectValue placeholder="Choose a school to view transactions..." />
              </SelectTrigger>
              <SelectContent>
                {schools.map((school) => (
                  <SelectItem key={school.id} value={school.id}>
                    {school.name} (ID: {school.id})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="bg-card rounded-xl border border-border shadow-sm">
            <div className="p-6 border-b border-border">
              <h3 className="text-lg font-semibold text-foreground">School Transaction Results</h3>
              {selectedSchoolId && (
                <p className="text-sm text-muted-foreground mt-1">
                  Showing transactions for {schools.find(s => s.id === selectedSchoolId)?.name}
                </p>
              )}
            </div>

            <div className="p-6">
              {!selectedSchoolId && (
                <div className="text-center py-12 text-muted-foreground">
                  <i className="fas fa-school text-6xl mb-6"></i>
                  <h4 className="text-lg font-medium mb-2">Select a School</h4>
                  <p>Choose a school from the dropdown above to view its transactions</p>
                </div>
              )}

              {selectedSchoolId && isLoading && (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="p-4 border border-border rounded-lg">
                      <Skeleton className="h-4 w-32 mb-2" />
                      <Skeleton className="h-4 w-48 mb-2" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                  ))}
                </div>
              )}

              {selectedSchoolId && !isLoading && data?.transactions && data.transactions.length === 0 && (
                <div className="text-center py-12 text-muted-foreground">
                  <i className="fas fa-inbox text-6xl mb-6"></i>
                  <h4 className="text-lg font-medium mb-2">No Transactions Found</h4>
                  <p>This school doesn't have any transactions yet.</p>
                </div>
              )}

              {selectedSchoolId && !isLoading && data?.transactions && data.transactions.length > 0 && (
                <div className="space-y-4">
                  <div className="mb-4 text-sm text-muted-foreground">
                    Found {data.total} transaction{data.total !== 1 ? 's' : ''}
                  </div>
                  
                  {data.transactions.map((transaction: Transaction) => (
                    <div 
                      key={transaction.collect_id} 
                      className="p-6 border border-border rounded-lg hover:bg-muted/50 hover:shadow-md transition-all duration-200"
                      data-testid={`card-transaction-${transaction.collect_id}`}
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h4 className="font-semibold text-foreground text-lg" data-testid={`text-order-id-${transaction.collect_id}`}>
                            {transaction.custom_order_id}
                          </h4>
                          <p className="text-sm text-muted-foreground" data-testid={`text-collect-id-${transaction.collect_id}`}>
                            Collect ID: {transaction.collect_id}
                          </p>
                        </div>
                        <span className={getStatusBadge(transaction.status)} data-testid={`status-${transaction.collect_id}`}>
                          {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-4">
                        <div>
                          <h5 className="text-sm font-medium text-muted-foreground mb-2">Student Details</h5>
                          <p className="font-medium text-foreground" data-testid={`text-student-name-${transaction.collect_id}`}>
                            {transaction.student_info.name}
                          </p>
                          <p className="text-sm text-muted-foreground" data-testid={`text-student-id-${transaction.collect_id}`}>
                            {transaction.student_info.id}
                          </p>
                          <p className="text-sm text-muted-foreground" data-testid={`text-student-email-${transaction.collect_id}`}>
                            {transaction.student_info.email}
                          </p>
                        </div>
                        
                        <div>
                          <h5 className="text-sm font-medium text-muted-foreground mb-2">Payment Details</h5>
                          <p className="font-bold text-foreground text-lg" data-testid={`text-amount-${transaction.collect_id}`}>
                            ₹{transaction.transaction_amount.toLocaleString()}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Order Amount: ₹{transaction.order_amount.toLocaleString()}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            via {transaction.gateway} ({transaction.payment_mode})
                          </p>
                        </div>
                        
                        <div>
                          <h5 className="text-sm font-medium text-muted-foreground mb-2">Transaction Info</h5>
                          <p className="text-sm text-foreground" data-testid={`text-payment-date-${transaction.collect_id}`}>
                            {formatDate(transaction.payment_time)}
                          </p>
                          {transaction.payment_message && (
                            <p className="text-sm text-muted-foreground mt-1">
                              {transaction.payment_message}
                            </p>
                          )}
                          {transaction.bank_reference && (
                            <p className="text-xs text-muted-foreground mt-1">
                              Ref: {transaction.bank_reference}
                            </p>
                          )}
                        </div>
                      </div>
                      
                      {transaction.error_message && transaction.error_message !== "NA" && (
                        <div className="mt-4 p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
                          <p className="text-sm text-destructive">
                            <i className="fas fa-exclamation-triangle mr-2"></i>
                            {transaction.error_message}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { transactionsApi } from "../lib/api";
import { Header } from "../components/layout/header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { Transaction } from "@shared/schema";

export default function StatusCheck() {
  const [customOrderId, setCustomOrderId] = useState("");
  const [result, setResult] = useState<Transaction | null>(null);
  const [error, setError] = useState<string | null>(null);

  const statusMutation = useMutation({
    mutationFn: (orderId: string) => transactionsApi.getTransactionStatus(orderId),
    onSuccess: (data) => {
      setResult(data);
      setError(null);
    },
    onError: (error: any) => {
      setError(error.message || "Transaction not found");
      setResult(null);
    },
  });

  const handleCheckStatus = () => {
    if (!customOrderId.trim()) {
      setError("Please enter a custom order ID");
      return;
    }
    
    setError(null);
    statusMutation.mutate(customOrderId.trim());
  };

  const getStatusBadge = (status: string) => {
    const baseClasses = "inline-flex items-center px-3 py-1 rounded-full text-sm font-medium";
    
    switch (status) {
      case "success":
        return `${baseClasses} bg-success/10 text-success`;
      case "pending":
        return `${baseClasses} bg-warning/10 text-warning`;
      case "failed":
        return `${baseClasses} bg-destructive/10 text-destructive`;
      default:
        return `${baseClasses} bg-muted text-muted-foreground`;
    }
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString("en-US", { 
      year: "numeric", 
      month: "long", 
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
  };

  return (
    <>
      <Header 
        title="Transaction Status Check" 
        subtitle="Check the current status of any transaction using its order ID" 
      />
      
      <div className="flex-1 overflow-auto p-6">
        <div className="max-w-2xl mx-auto">
          <div className="bg-card rounded-xl border border-border p-8 shadow-sm">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-search text-primary text-2xl"></i>
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-2">Check Transaction Status</h3>
              <p className="text-muted-foreground">Enter your custom order ID to get real-time transaction status</p>
            </div>

            <div className="space-y-6">
              <div>
                <Label htmlFor="customOrderId" className="block text-sm font-medium text-foreground mb-3">
                  Custom Order ID
                </Label>
                <Input
                  id="customOrderId"
                  type="text"
                  placeholder="e.g., ORD-2024-001247, ORD-1706123456-ABC123"
                  className="w-full text-lg p-4"
                  value={customOrderId}
                  onChange={(e) => setCustomOrderId(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      handleCheckStatus();
                    }
                  }}
                  data-testid="input-custom-order-id"
                />
                <p className="text-sm text-muted-foreground mt-2">
                  This is the order ID provided to you when the transaction was initiated.
                </p>
              </div>
              
              <Button
                className="w-full text-lg py-6"
                onClick={handleCheckStatus}
                disabled={statusMutation.isPending}
                data-testid="button-check-status"
              >
                {statusMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-3"></i>Checking Status...
                  </>
                ) : (
                  <>
                    <i className="fas fa-search mr-3"></i>Check Transaction Status
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Error State */}
          {error && (
            <div className="mt-6 bg-card rounded-xl border border-border p-6 shadow-sm">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-destructive/10 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-exclamation-circle text-destructive text-xl"></i>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-destructive mb-2">Transaction Not Found</h4>
                  <p className="text-muted-foreground" data-testid="text-error">
                    {error}
                  </p>
                  <p className="text-sm text-muted-foreground mt-2">
                    Please verify the order ID and try again. Make sure you're using the correct format.
                  </p>
                </div>
              </div>
            </div>
          )}
          
          {/* Success Result */}
          {result && (
            <div className="mt-6 bg-card rounded-xl border border-border shadow-sm overflow-hidden" data-testid="status-result">
              <div className="p-6 border-b border-border bg-muted/20">
                <div className="flex items-center justify-between">
                  <h4 className="text-xl font-bold text-foreground">Transaction Details</h4>
                  <span className={getStatusBadge(result.status)} data-testid="status-badge">
                    <i className={`mr-2 ${
                      result.status === 'success' ? 'fas fa-check-circle' :
                      result.status === 'pending' ? 'fas fa-clock' : 'fas fa-times-circle'
                    }`}></i>
                    {result.status.charAt(0).toUpperCase() + result.status.slice(1)}
                  </span>
                </div>
              </div>

              <div className="p-6 space-y-6">
                {/* Order Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h5 className="text-sm font-medium text-muted-foreground mb-1">Custom Order ID</h5>
                      <p className="text-lg font-semibold text-foreground" data-testid="text-order-id">
                        {result.custom_order_id}
                      </p>
                    </div>
                    <div>
                      <h5 className="text-sm font-medium text-muted-foreground mb-1">Collect ID</h5>
                      <p className="text-foreground font-mono text-sm" data-testid="text-collect-id">
                        {result.collect_id}
                      </p>
                    </div>
                    <div>
                      <h5 className="text-sm font-medium text-muted-foreground mb-1">School ID</h5>
                      <p className="text-foreground font-mono text-sm" data-testid="text-school-id">
                        {result.school_id}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h5 className="text-sm font-medium text-muted-foreground mb-1">Transaction Amount</h5>
                      <p className="text-2xl font-bold text-foreground" data-testid="text-amount">
                        ₹{result.transaction_amount.toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <h5 className="text-sm font-medium text-muted-foreground mb-1">Order Amount</h5>
                      <p className="text-lg text-muted-foreground">
                        ₹{result.order_amount.toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Student Information */}
                <div className="p-4 bg-muted/30 rounded-lg">
                  <h5 className="text-sm font-medium text-muted-foreground mb-3">Student Information</h5>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Name</p>
                      <p className="font-medium text-foreground" data-testid="text-student-name">
                        {result.student_info.name}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Student ID</p>
                      <p className="font-medium text-foreground" data-testid="text-student-id">
                        {result.student_info.id}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Email</p>
                      <p className="font-medium text-foreground" data-testid="text-student-email">
                        {result.student_info.email}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Payment Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h5 className="text-sm font-medium text-muted-foreground mb-1">Payment Gateway</h5>
                      <p className="text-foreground font-medium" data-testid="text-gateway">
                        <i className="fas fa-credit-card mr-2 text-primary"></i>
                        {result.gateway}
                      </p>
                    </div>
                    <div>
                      <h5 className="text-sm font-medium text-muted-foreground mb-1">Payment Mode</h5>
                      <p className="text-foreground" data-testid="text-payment-mode">
                        {result.payment_mode}
                      </p>
                    </div>
                    {result.bank_reference && result.bank_reference !== "NA" && (
                      <div>
                        <h5 className="text-sm font-medium text-muted-foreground mb-1">Bank Reference</h5>
                        <p className="text-foreground font-mono text-sm" data-testid="text-bank-reference">
                          {result.bank_reference}
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h5 className="text-sm font-medium text-muted-foreground mb-1">Payment Time</h5>
                      <p className="text-foreground" data-testid="text-payment-time">
                        {formatDate(result.payment_time)}
                      </p>
                    </div>
                    {result.payment_details && (
                      <div>
                        <h5 className="text-sm font-medium text-muted-foreground mb-1">Payment Details</h5>
                        <p className="text-foreground" data-testid="text-payment-details">
                          {result.payment_details}
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Status Messages */}
                {result.payment_message && result.payment_message !== "NA" && (
                  <div className="p-4 bg-success/10 border border-success/20 rounded-lg">
                    <h5 className="text-sm font-medium text-success mb-1">Payment Message</h5>
                    <p className="text-success" data-testid="text-payment-message">
                      {result.payment_message}
                    </p>
                  </div>
                )}

                {result.error_message && result.error_message !== "NA" && (
                  <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg">
                    <h5 className="text-sm font-medium text-destructive mb-1">Error Message</h5>
                    <p className="text-destructive" data-testid="text-error-message">
                      <i className="fas fa-exclamation-triangle mr-2"></i>
                      {result.error_message}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

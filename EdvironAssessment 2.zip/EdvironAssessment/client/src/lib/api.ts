import { apiRequest } from "./queryClient";
import type { 
  Transaction, 
  CreatePayment, 
  WebhookPayload 
} from "@shared/schema";
import type { 
  DashboardStats, 
  TransactionFilters, 
  PaginatedResponse, 
  AuthResponse 
} from "../types";

// Auth API
export const authApi = {
  login: async (username: string, password: string): Promise<AuthResponse> => {
    const response = await apiRequest("POST", "/api/auth/login", { username, password });
    return response.json();
  },
};

// Payment API
export const paymentApi = {
  createPayment: async (paymentData: CreatePayment) => {
    const response = await apiRequest("POST", "/api/create-payment", paymentData);
    return response.json();
  },

  webhook: async (webhookData: WebhookPayload) => {
    const response = await apiRequest("POST", "/api/webhook", webhookData);
    return response.json();
  },
};

// Transactions API
export const transactionsApi = {
  getAllTransactions: async (filters?: TransactionFilters): Promise<PaginatedResponse<Transaction>> => {
    const params = new URLSearchParams();
    if (filters?.search) params.append("search", filters.search);
    if (filters?.status) params.append("status", filters.status);
    if (filters?.schoolId) params.append("schoolId", filters.schoolId);
    if (filters?.fromDate) params.append("fromDate", filters.fromDate);
    if (filters?.toDate) params.append("toDate", filters.toDate);
    if (filters?.page) params.append("page", filters.page.toString());
    if (filters?.limit) params.append("limit", filters.limit.toString());

    const response = await apiRequest("GET", `/api/transactions?${params.toString()}`);
    return response.json();
  },

  getTransactionsBySchool: async (schoolId: string, page = 1, limit = 10): Promise<PaginatedResponse<Transaction>> => {
    const response = await apiRequest("GET", `/api/transactions/school/${schoolId}?page=${page}&limit=${limit}`);
    return response.json();
  },

  getTransactionStatus: async (customOrderId: string): Promise<Transaction> => {
    const response = await apiRequest("GET", `/api/transaction-status/${customOrderId}`);
    return response.json();
  },
};

// Dashboard API
export const dashboardApi = {
  getStats: async (): Promise<DashboardStats> => {
    const response = await apiRequest("GET", "/api/dashboard/stats");
    return response.json();
  },
};

// Helper to set auth token
export const setAuthToken = (token: string) => {
  localStorage.setItem("auth_token", token);
};

export const getAuthToken = () => {
  return localStorage.getItem("auth_token");
};

export const removeAuthToken = () => {
  localStorage.removeItem("auth_token");
};

import { z } from "zod";

// User Schema for JWT Authentication
export const userSchema = z.object({
  id: z.string(),
  username: z.string(),
  password: z.string(),
});

export const insertUserSchema = userSchema.omit({ id: true });

export type User = z.infer<typeof userSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;

// Student Info Schema
export const studentInfoSchema = z.object({
  name: z.string(),
  id: z.string(),
  email: z.string().email(),
});

// Order Schema
export const orderSchema = z.object({
  _id: z.string(),
  school_id: z.string(),
  trustee_id: z.string(),
  student_info: studentInfoSchema,
  gateway_name: z.string(),
  custom_order_id: z.string().optional(),
  created_at: z.date().optional(),
});

export const insertOrderSchema = orderSchema.omit({ _id: true, created_at: true });

// Order Status Schema
export const orderStatusSchema = z.object({
  collect_id: z.string(), // Reference to Order schema (_id)
  order_amount: z.number(),
  transaction_amount: z.number(),
  payment_mode: z.string(),
  payment_details: z.string(),
  bank_reference: z.string(),
  payment_message: z.string(),
  status: z.enum(["success", "pending", "failed"]),
  error_message: z.string(),
  payment_time: z.date(),
});

export const insertOrderStatusSchema = orderStatusSchema;

// Webhook Logs Schema
export const webhookLogSchema = z.object({
  id: z.string(),
  order_id: z.string(),
  payload: z.record(z.any()),
  status: z.number(),
  timestamp: z.date(),
});

export const insertWebhookLogSchema = webhookLogSchema.omit({ id: true, timestamp: true });

// Combined Transaction Schema (for aggregated data)
export const transactionSchema = z.object({
  collect_id: z.string(),
  school_id: z.string(),
  school_name: z.string().optional(),
  gateway: z.string(),
  order_amount: z.number(),
  transaction_amount: z.number(),
  status: z.enum(["success", "pending", "failed"]),
  custom_order_id: z.string().optional(),
  student_info: studentInfoSchema,
  payment_mode: z.string(),
  payment_details: z.string(),
  bank_reference: z.string(),
  payment_message: z.string(),
  payment_time: z.date(),
  error_message: z.string(),
});

// Payment Creation Schema
export const createPaymentSchema = z.object({
  school_id: z.string(),
  trustee_id: z.string(),
  student_info: studentInfoSchema,
  amount: z.number().positive(),
  gateway_name: z.string(),
});

// Webhook Payload Schema
export const webhookPayloadSchema = z.object({
  status: z.number(),
  order_info: z.object({
    order_id: z.string(),
    order_amount: z.number(),
    transaction_amount: z.number(),
    gateway: z.string(),
    bank_reference: z.string(),
    status: z.string(),
    payment_mode: z.string(),
    payemnt_details: z.string(), // Note: typo in original spec
    Payment_message: z.string(), // Note: capitalization in original spec
    payment_time: z.string(),
    error_message: z.string(),
  }),
});

export type Order = z.infer<typeof orderSchema>;
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type OrderStatus = z.infer<typeof orderStatusSchema>;
export type InsertOrderStatus = z.infer<typeof insertOrderStatusSchema>;
export type WebhookLog = z.infer<typeof webhookLogSchema>;
export type InsertWebhookLog = z.infer<typeof insertWebhookLogSchema>;
export type Transaction = z.infer<typeof transactionSchema>;
export type CreatePayment = z.infer<typeof createPaymentSchema>;
export type WebhookPayload = z.infer<typeof webhookPayloadSchema>;

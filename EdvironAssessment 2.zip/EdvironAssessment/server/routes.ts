import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import jwt from "jsonwebtoken";
import axios from "axios";

// Extend Request interface to include user property
declare global {
  namespace Express {
    interface Request {
      user?: any;
    }
  }
}
import { 
  createPaymentSchema, 
  webhookPayloadSchema,
  type CreatePayment,
  type WebhookPayload 
} from "@shared/schema";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";
const API_KEY = process.env.API_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0cnVzdGVlSWQiOiI2NWIwZTU1MmRkMzE5NTBhOWI0MWM1YmEiLCJJbmRleE9mQXBpS2V5Ijo2LCJpYXQiOjE3MTE2MjIyNzAsImV4cCI6MTc0MzE3OTgzMH0.Rye77Dp59GGxwCmwWekJHRj6edXWJnff9finjMhxKuw";
const PG_KEY = process.env.PG_KEY || "edvtest01";
const SCHOOL_ID = process.env.SCHOOL_ID || "65b0e6293e9f76a9694d84b4";

// Middleware to verify JWT token
const authenticateToken = (req: Request, res: Response, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.status(403).json({ message: 'Invalid token' });
    req.user = user;
    next();
  });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password required" });
      }

      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign(
        { id: user.id, username: user.username },
        JWT_SECRET,
        { expiresIn: '24h' }
      );

      res.json({ 
        token, 
        user: { id: user.id, username: user.username }
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Create payment route
  app.post("/api/create-payment", authenticateToken, async (req: Request, res: Response) => {
    try {
      const validationResult = createPaymentSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Invalid payment data", 
          errors: validationResult.error.errors 
        });
      }

      const paymentData: CreatePayment = validationResult.data;

      // Create order in database
      const order = await storage.createOrder({
        school_id: paymentData.school_id,
        trustee_id: paymentData.trustee_id,
        student_info: paymentData.student_info,
        gateway_name: paymentData.gateway_name,
      });

      // Create JWT payload for payment API
      const paymentPayload = {
        collect_id: order._id,
        amount: paymentData.amount,
        school_id: paymentData.school_id,
        trustee_id: paymentData.trustee_id,
        student_info: paymentData.student_info,
        gateway_name: paymentData.gateway_name,
        custom_order_id: order.custom_order_id,
      };

      const signedPayload = jwt.sign(paymentPayload, JWT_SECRET);

      // Call payment gateway API
      try {
        const paymentResponse = await axios.post(
          "https://api.edviron.com/create-collect-request", // Replace with actual API endpoint
          {
            pg_key: PG_KEY,
            payload: signedPayload,
          },
          {
            headers: {
              'Authorization': `Bearer ${API_KEY}`,
              'Content-Type': 'application/json',
            },
          }
        );

        res.json({
          success: true,
          order_id: order._id,
          custom_order_id: order.custom_order_id,
          payment_url: paymentResponse.data.payment_url,
        });
      } catch (paymentError) {
        // If payment gateway call fails, still return order info but indicate gateway error
        res.json({
          success: false,
          order_id: order._id,
          custom_order_id: order.custom_order_id,
          message: "Order created but payment gateway unavailable",
        });
      }
    } catch (error) {
      console.error("Create payment error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Webhook endpoint
  app.post("/api/webhook", async (req: Request, res: Response) => {
    try {
      const validationResult = webhookPayloadSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Invalid webhook payload", 
          errors: validationResult.error.errors 
        });
      }

      const webhookData: WebhookPayload = validationResult.data;

      // Log webhook
      await storage.createWebhookLog({
        order_id: webhookData.order_info.order_id,
        payload: req.body,
        status: webhookData.status,
      });

      // Update order status
      const orderStatus = {
        collect_id: webhookData.order_info.order_id,
        order_amount: webhookData.order_info.order_amount,
        transaction_amount: webhookData.order_info.transaction_amount,
        payment_mode: webhookData.order_info.payment_mode,
        payment_details: webhookData.order_info.payemnt_details, // Note: typo from original spec
        bank_reference: webhookData.order_info.bank_reference,
        payment_message: webhookData.order_info.Payment_message, // Note: capitalization from original spec
        status: webhookData.order_info.status === "success" ? "success" as const : 
                webhookData.order_info.status === "pending" ? "pending" as const : "failed" as const,
        error_message: webhookData.order_info.error_message,
        payment_time: new Date(webhookData.order_info.payment_time),
      };

      await storage.createOrderStatus(orderStatus);

      res.json({ success: true, message: "Webhook processed successfully" });
    } catch (error) {
      console.error("Webhook error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get all transactions
  app.get("/api/transactions", async (req: Request, res: Response) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      
      const filters = {
        search: req.query.search as string,
        status: req.query.status as string,
        schoolId: req.query.schoolId as string,
        fromDate: req.query.fromDate ? new Date(req.query.fromDate as string) : undefined,
        toDate: req.query.toDate ? new Date(req.query.toDate as string) : undefined,
      };

      const result = await storage.getAllTransactions(page, limit, filters);
      
      res.json({
        transactions: result.transactions,
        total: result.total,
        page,
        limit,
        totalPages: Math.ceil(result.total / limit),
      });
    } catch (error) {
      console.error("Get transactions error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get transactions by school
  app.get("/api/transactions/school/:schoolId", async (req: Request, res: Response) => {
    try {
      const { schoolId } = req.params;
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;

      const result = await storage.getTransactionsBySchool(schoolId, page, limit);
      
      res.json({
        transactions: result.transactions,
        total: result.total,
        page,
        limit,
        totalPages: Math.ceil(result.total / limit),
      });
    } catch (error) {
      console.error("Get school transactions error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Check transaction status
  app.get("/api/transaction-status/:custom_order_id", async (req: Request, res: Response) => {
    try {
      const { custom_order_id } = req.params;
      
      const transaction = await storage.getTransactionByCustomOrderId(custom_order_id);
      
      if (!transaction) {
        return res.status(404).json({ message: "Transaction not found" });
      }

      res.json(transaction);
    } catch (error) {
      console.error("Get transaction status error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get dashboard stats
  app.get("/api/dashboard/stats", async (req: Request, res: Response) => {
    try {
      const { transactions } = await storage.getAllTransactions(1, 1000); // Get all for stats
      
      const totalTransactions = transactions.length;
      const successfulPayments = transactions.filter(t => t.status === "success").length;
      const failedTransactions = transactions.filter(t => t.status === "failed").length;
      const totalRevenue = transactions
        .filter(t => t.status === "success")
        .reduce((sum, t) => sum + t.transaction_amount, 0);

      res.json({
        totalTransactions,
        successfulPayments,
        failedTransactions,
        totalRevenue,
        successRate: totalTransactions > 0 ? ((successfulPayments / totalTransactions) * 100).toFixed(1) : "0",
        failureRate: totalTransactions > 0 ? ((failedTransactions / totalTransactions) * 100).toFixed(1) : "0",
      });
    } catch (error) {
      console.error("Get dashboard stats error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

import { 
  type User, 
  type InsertUser, 
  type Order, 
  type InsertOrder,
  type OrderStatus,
  type InsertOrderStatus,
  type WebhookLog,
  type InsertWebhookLog,
  type Transaction
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Order methods
  createOrder(order: InsertOrder): Promise<Order>;
  getOrder(id: string): Promise<Order | undefined>;
  getOrdersBySchool(schoolId: string): Promise<Order[]>;

  // Order Status methods
  createOrderStatus(orderStatus: InsertOrderStatus): Promise<OrderStatus>;
  updateOrderStatus(collectId: string, orderStatus: Partial<OrderStatus>): Promise<OrderStatus | undefined>;
  getOrderStatus(collectId: string): Promise<OrderStatus | undefined>;

  // Webhook Log methods
  createWebhookLog(webhookLog: InsertWebhookLog): Promise<WebhookLog>;

  // Transaction methods (aggregated data)
  getAllTransactions(page?: number, limit?: number, filters?: {
    search?: string;
    status?: string;
    schoolId?: string;
    fromDate?: Date;
    toDate?: Date;
  }): Promise<{ transactions: Transaction[], total: number }>;
  
  getTransactionsBySchool(schoolId: string, page?: number, limit?: number): Promise<{ transactions: Transaction[], total: number }>;
  
  getTransactionByCustomOrderId(customOrderId: string): Promise<Transaction | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private orders: Map<string, Order> = new Map();
  private orderStatuses: Map<string, OrderStatus> = new Map();
  private webhookLogs: Map<string, WebhookLog> = new Map();

  constructor() {
    // Create a default admin user
    this.createUser({ username: 'admin', password: 'admin123' });
    
    // Add sample transaction data
    this.initializeSampleData();
  }

  private async initializeSampleData() {
    // Using exact data from PDF specifications
    const schoolId = "65b0e6293e9f76a9694d84b4"; // From PDF
    const trusteeId = "65b0e552dd319500a9b41c5ba"; // From PDF
    
    const students = [
      { name: "Aarav Kumar", id: "2024001", email: "aarav.kumar@dps.edu.in" },
      { name: "Diya Sharma", id: "2024002", email: "diya.sharma@dps.edu.in" },
      { name: "Arjun Patel", id: "2024003", email: "arjun.patel@dps.edu.in" },
      { name: "Ananya Singh", id: "2024004", email: "ananya.singh@dps.edu.in" },
      { name: "Ishaan Verma", id: "2024005", email: "ishaan.verma@dps.edu.in" },
      { name: "Kavya Reddy", id: "2024006", email: "kavya.reddy@dps.edu.in" },
      { name: "Rohan Gupta", id: "2024007", email: "rohan.gupta@dps.edu.in" },
      { name: "Sanya Joshi", id: "2024008", email: "sanya.joshi@dps.edu.in" },
      { name: "Vihaan Das", id: "2024009", email: "vihaan.das@dps.edu.in" },
      { name: "Mira Agarwal", id: "2024010", email: "mira.agarwal@dps.edu.in" }
    ];

    // Sample transactions matching PDF format
    const sampleTransactions = [
      {
        student: students[0],
        orderAmount: 2000,
        transactionAmount: 2200,
        gateway: "PhonePe",
        status: "success" as const,
        paymentMode: "upi",
        paymentDetails: "success@ybl",
        bankReference: "YESBNK222",
        paymentMessage: "payment success",
        errorMessage: "NA",
        paymentTime: new Date("2025-04-23T08:14:21.945Z")
      },
      {
        student: students[1],
        orderAmount: 5000,
        transactionAmount: 5150,
        gateway: "GooglePay",
        status: "success" as const,
        paymentMode: "upi",
        paymentDetails: "gpay@success",
        bankReference: "HDFCBNK123",
        paymentMessage: "payment success",
        errorMessage: "NA",
        paymentTime: new Date("2025-04-22T10:30:15.123Z")
      },
      {
        student: students[2],
        orderAmount: 15000,
        transactionAmount: 15300,
        gateway: "Razorpay",
        status: "pending" as const,
        paymentMode: "net_banking",
        paymentDetails: "processing",
        bankReference: "",
        paymentMessage: "payment pending",
        errorMessage: "NA",
        paymentTime: new Date("2025-04-21T14:45:30.456Z")
      },
      {
        student: students[3],
        orderAmount: 8500,
        transactionAmount: 8650,
        gateway: "PhonePe",
        status: "failed" as const,
        paymentMode: "debit_card",
        paymentDetails: "failed",
        bankReference: "",
        paymentMessage: "payment failed",
        errorMessage: "Insufficient balance",
        paymentTime: new Date("2025-04-20T16:20:45.789Z")
      },
      {
        student: students[4],
        orderAmount: 12000,
        transactionAmount: 12180,
        gateway: "Paytm",
        status: "success" as const,
        paymentMode: "wallet",
        paymentDetails: "paytm@success",
        bankReference: "PAYTM567",
        paymentMessage: "payment success",
        errorMessage: "NA",
        paymentTime: new Date("2025-04-19T09:15:22.345Z")
      },
      {
        student: students[5],
        orderAmount: 25000,
        transactionAmount: 25500,
        gateway: "Razorpay",
        status: "success" as const,
        paymentMode: "credit_card",
        paymentDetails: "card@success",
        bankReference: "ICICIBNK890",
        paymentMessage: "payment success",
        errorMessage: "NA",
        paymentTime: new Date("2025-04-18T11:45:10.678Z")
      },
      {
        student: students[6],
        orderAmount: 3500,
        transactionAmount: 3620,
        gateway: "GooglePay",
        status: "pending" as const,
        paymentMode: "upi",
        paymentDetails: "processing",
        bankReference: "",
        paymentMessage: "payment pending",
        errorMessage: "NA",
        paymentTime: new Date("2025-04-17T13:25:35.912Z")
      },
      {
        student: students[7],
        orderAmount: 18000,
        transactionAmount: 18360,
        gateway: "PhonePe",
        status: "success" as const,
        paymentMode: "upi",
        paymentDetails: "phonepe@success",
        bankReference: "SBIBNK445",
        paymentMessage: "payment success",
        errorMessage: "NA",
        paymentTime: new Date("2025-04-16T15:50:28.234Z")
      },
      {
        student: students[8],
        orderAmount: 7500,
        transactionAmount: 7650,
        gateway: "Razorpay",
        status: "failed" as const,
        paymentMode: "net_banking",
        paymentDetails: "failed",
        bankReference: "",
        paymentMessage: "payment failed",
        errorMessage: "Transaction timeout",
        paymentTime: new Date("2025-04-15T12:10:15.567Z")
      },
      {
        student: students[9],
        orderAmount: 4200,
        transactionAmount: 4284,
        gateway: "Paytm",
        status: "success" as const,
        paymentMode: "wallet",
        paymentDetails: "wallet@success",
        bankReference: "PAYTM789",
        paymentMessage: "payment success",
        errorMessage: "NA",
        paymentTime: new Date("2025-04-14T17:35:40.890Z")
      }
    ];

    // Create orders and order statuses
    for (const txn of sampleTransactions) {
      // Create order
      const order = await this.createOrder({
        school_id: schoolId,
        trustee_id: trusteeId,
        student_info: txn.student,
        gateway_name: txn.gateway,
      });

      // Create order status
      await this.createOrderStatus({
        collect_id: order._id,
        order_amount: txn.orderAmount,
        transaction_amount: txn.transactionAmount,
        payment_mode: txn.paymentMode,
        payment_details: txn.paymentDetails,
        bank_reference: txn.bankReference,
        payment_message: txn.paymentMessage,
        status: txn.status,
        error_message: txn.errorMessage,
        payment_time: txn.paymentTime,
      });
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const _id = randomUUID();
    const order: Order = { 
      ...insertOrder, 
      _id,
      custom_order_id: `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      created_at: new Date()
    };
    this.orders.set(_id, order);
    return order;
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getOrdersBySchool(schoolId: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(order => order.school_id === schoolId);
  }

  async createOrderStatus(orderStatus: InsertOrderStatus): Promise<OrderStatus> {
    this.orderStatuses.set(orderStatus.collect_id, orderStatus);
    return orderStatus;
  }

  async updateOrderStatus(collectId: string, updates: Partial<OrderStatus>): Promise<OrderStatus | undefined> {
    const existing = this.orderStatuses.get(collectId);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.orderStatuses.set(collectId, updated);
    return updated;
  }

  async getOrderStatus(collectId: string): Promise<OrderStatus | undefined> {
    return this.orderStatuses.get(collectId);
  }

  async createWebhookLog(webhookLog: InsertWebhookLog): Promise<WebhookLog> {
    const id = randomUUID();
    const log: WebhookLog = {
      ...webhookLog,
      id,
      timestamp: new Date()
    };
    this.webhookLogs.set(id, log);
    return log;
  }

  async getAllTransactions(
    page = 1, 
    limit = 10, 
    filters?: {
      search?: string;
      status?: string;
      schoolId?: string;
      fromDate?: Date;
      toDate?: Date;
    }
  ): Promise<{ transactions: Transaction[], total: number }> {
    const transactions = this.aggregateTransactions();
    let filtered = transactions;

    // Apply filters
    if (filters?.search) {
      const search = filters.search.toLowerCase();
      filtered = filtered.filter(t => 
        t.collect_id.toLowerCase().includes(search) ||
        t.custom_order_id?.toLowerCase().includes(search) ||
        t.student_info.name.toLowerCase().includes(search) ||
        t.student_info.email.toLowerCase().includes(search)
      );
    }

    if (filters?.status) {
      filtered = filtered.filter(t => t.status === filters.status);
    }

    if (filters?.schoolId) {
      filtered = filtered.filter(t => t.school_id === filters.schoolId);
    }

    if (filters?.fromDate) {
      filtered = filtered.filter(t => t.payment_time >= filters.fromDate!);
    }

    if (filters?.toDate) {
      filtered = filtered.filter(t => t.payment_time <= filters.toDate!);
    }

    // Sort by payment_time descending
    filtered.sort((a, b) => b.payment_time.getTime() - a.payment_time.getTime());

    const total = filtered.length;
    const startIndex = (page - 1) * limit;
    const paginatedTransactions = filtered.slice(startIndex, startIndex + limit);

    return { transactions: paginatedTransactions, total };
  }

  async getTransactionsBySchool(schoolId: string, page = 1, limit = 10): Promise<{ transactions: Transaction[], total: number }> {
    return this.getAllTransactions(page, limit, { schoolId });
  }

  async getTransactionByCustomOrderId(customOrderId: string): Promise<Transaction | undefined> {
    const transactions = this.aggregateTransactions();
    return transactions.find(t => t.custom_order_id === customOrderId);
  }

  private aggregateTransactions(): Transaction[] {
    const transactions: Transaction[] = [];

    for (const order of Array.from(this.orders.values())) {
      const orderStatus = this.orderStatuses.get(order._id);
      if (orderStatus) {
        transactions.push({
          collect_id: order._id,
          school_id: order.school_id,
          gateway: order.gateway_name,
          order_amount: orderStatus.order_amount,
          transaction_amount: orderStatus.transaction_amount,
          status: orderStatus.status,
          custom_order_id: order.custom_order_id,
          student_info: order.student_info,
          payment_mode: orderStatus.payment_mode,
          payment_details: orderStatus.payment_details,
          bank_reference: orderStatus.bank_reference,
          payment_message: orderStatus.payment_message,
          payment_time: orderStatus.payment_time,
          error_message: orderStatus.error_message,
        });
      }
    }

    return transactions;
  }
}

export const storage = new MemStorage();
